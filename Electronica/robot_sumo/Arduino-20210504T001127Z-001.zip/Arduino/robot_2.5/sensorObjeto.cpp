#include "sensorObjeto.h"

void sensorObjetoLectura(void){
  //Limpieza de ruido
  int i=0;
  lectura_objeto_0 = 0;
  lectura_objeto_1 = 0;
  lectura_objeto_2 = 0;
  lectura_objeto_3 = 0;
  lectura_objeto_4 = 0;
  lectura_objeto_5 = 0;

  do{
  lectura_objeto_0 += analogRead(A0); // Lectura de sensor de objeto 0
  lectura_objeto_1 += analogRead(A1); // Lectura de sensor de objeto 1
  lectura_objeto_2 += analogRead(A2);
  lectura_objeto_3 += analogRead(A3);
  lectura_objeto_4 += analogRead(A4);
  lectura_objeto_5 += analogRead(A5); // Lectura de sensor de objeto 5
  i=i+1;
  }while(i<16);

  lectura_objeto_0 = lectura_objeto_0/i;
  lectura_objeto_1 = lectura_objeto_1/i;
  lectura_objeto_2 = lectura_objeto_2/i;
  lectura_objeto_3 = lectura_objeto_3/i;
  lectura_objeto_4 = lectura_objeto_4/i;
  lectura_objeto_5 = lectura_objeto_5/i;
}
