#include <arduino.h>

int lectura_objeto_0 = 0;                 //LECTURA DE ROBOT RIVAL
int lectura_objeto_1 = 0;                 //CONEXION DE A0 ~ A5
int lectura_objeto_2 = 0;                 //  |A0--A1--A2|   DELANTEROS
int lectura_objeto_3 = 0;                 //  |          |   
int lectura_objeto_4 = 0;                 //  A3        A4   LATERALES
int lectura_objeto_5 = 0;                 //  |_ _ A5 _ _|   TRASERO


void sensorObjetoConfig(void);
void sensorObjetoLectura(void);
