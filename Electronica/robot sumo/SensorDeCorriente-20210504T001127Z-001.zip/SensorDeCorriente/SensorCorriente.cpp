#include "SensorCorriente.h"
#include "Digito.h"
float sensibilidad = 0.185; //Sensibilidad para 5A; 20A = 0.100; 30A = 0.066
float voltaje_sensor;
float corriente = 0;
float I;

void sensor_setup(void){
  Serial.begin(9600);
}

float muestra_corriente(void){
  I = get_corriente(2000); //Promedio de muestras
  
  digito_activo(I);
  //Serial.println (I);
  return I;
}


float get_corriente(int n_muestras){
  for(int i = 0; i < n_muestras; i++){
    voltaje_sensor = analogRead(SENSOR_PIN)*(5.0/1023.0); //Lectura del sensor
    corriente+=(voltaje_sensor - 2.5)/sensibilidad; //Ecuacion para obtener corriente
    digito_activo(I);
  }
  corriente = corriente/n_muestras;
  return(corriente);
}
