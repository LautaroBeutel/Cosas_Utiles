#include <arduino.h>

#define SENSOR_PIN A3

float muestra_voltaje(void);
float get_voltaje(int n_muestras);
