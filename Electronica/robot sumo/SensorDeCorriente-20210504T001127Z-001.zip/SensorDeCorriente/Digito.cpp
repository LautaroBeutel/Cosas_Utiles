#include "digito.h"

int numero = 0;
int numero_a = 0; //primer string
int numero_b = 0;
int numero_c = 0;
int numero_d = 0;

int numero_act = 0;

void digito_setup(){
  Serial.begin(9600);       // 0   1   2   3   4   5   6   7   8   9
  pinMode(PIN_A,OUTPUT);    // 0 - 1 - 0 - 1 - 0 - 1 - 0 - 1 - 0 - 1
  pinMode(PIN_B,OUTPUT);    // 0 - 0 - 1 - 1 - 0 - 0 - 1 - 1 - 0 - 0
  pinMode(PIN_C,OUTPUT);    // 0 - 0 - 0 - 0 - 1 - 1 - 1 - 1 - 0 - 0
  pinMode(PIN_D,OUTPUT);    // 0 - 0 - 0 - 0 - 0 - 0 - 0 - 0 - 1 - 1
  pinMode(UNI_1,OUTPUT);
  pinMode(UNI_2,OUTPUT);
  pinMode(UNI_3,OUTPUT);
  pinMode(UNI_4,OUTPUT);
}

float digito_activo(float valor){
  numero = valor * 1000;
  numero_a =  numero / 1000;
  numero_b = (numero - numero_a * 1000)/100;
  numero_c = (numero - numero_a * 1000 - numero_b * 100)/10;
  numero_d = (numero - numero_a * 1000 - numero_b * 100 - numero_c *10);

  //for (int contador = 0; contador < 20;contador++){
  digitalWrite(UNI_1,HIGH);   //Multiplexado
  digitalWrite(UNI_2,LOW);
  digitalWrite(UNI_3,LOW);
  digitalWrite(UNI_4,LOW);
  numero_act = numero_a;
  actualizar_numero();
  delay(1);

  digitalWrite(UNI_1,LOW);
  digitalWrite(UNI_2,HIGH);
  digitalWrite(UNI_3,LOW);
  digitalWrite(UNI_4,LOW);
  numero_act = numero_b;
  actualizar_numero();
  delay(1);

  digitalWrite(UNI_1,LOW);
  digitalWrite(UNI_2,LOW);
  digitalWrite(UNI_3,HIGH);
  digitalWrite(UNI_4,LOW);
  numero_act = numero_c;
  actualizar_numero();
  delay(1);

  digitalWrite(UNI_1,LOW);
  digitalWrite(UNI_2,LOW);
  digitalWrite(UNI_3,LOW);
  digitalWrite(UNI_4,HIGH);
  numero_act = numero_d;
  actualizar_numero();
  delay(1);
  Serial.println ("");

  digitalWrite(UNI_1,LOW);
  digitalWrite(UNI_2,LOW);
  digitalWrite(UNI_3,LOW);
  digitalWrite(UNI_4,LOW);
  //}
}

void actualizar_numero(){
  switch(numero_act){
    case 0:
      digitalWrite (PIN_A,LOW);
      digitalWrite (PIN_B,LOW);
      digitalWrite (PIN_C,LOW);
      digitalWrite (PIN_D,LOW);
      //Serial.print ("0");
      break;
    case 1:
      digitalWrite (PIN_A,HIGH);
      digitalWrite (PIN_B,LOW);
      digitalWrite (PIN_C,LOW);
      digitalWrite (PIN_D,LOW);
      Serial.print ("1");
      break;
    case 2:
      digitalWrite (PIN_A,LOW);
      digitalWrite (PIN_B,HIGH);
      digitalWrite (PIN_C,LOW);
      digitalWrite (PIN_D,LOW);
      Serial.print ("2");
      break;
    case 3:
      digitalWrite (PIN_A,HIGH);
      digitalWrite (PIN_B,HIGH);
      digitalWrite (PIN_C,LOW);
      digitalWrite (PIN_D,LOW);
      Serial.print ("3");
      break;
    case 4:
      digitalWrite (PIN_A,LOW);
      digitalWrite (PIN_B,LOW);
      digitalWrite (PIN_C,HIGH);
      digitalWrite (PIN_D,LOW);
      Serial.print ("4");
      break;
    case 5:
      digitalWrite (PIN_A,HIGH);
      digitalWrite (PIN_B,LOW);
      digitalWrite (PIN_C,HIGH);
      digitalWrite (PIN_D,LOW);
      Serial.print ("5");
      break;
    case 6:
      digitalWrite (PIN_A,LOW);
      digitalWrite (PIN_B,HIGH);
      digitalWrite (PIN_C,HIGH);
      digitalWrite (PIN_D,LOW);
      Serial.print ("6");
      break;
    case 7:
      digitalWrite (PIN_A,HIGH);
      digitalWrite (PIN_B,HIGH);
      digitalWrite (PIN_C,HIGH);
      digitalWrite (PIN_D,LOW);
      Serial.print ("7");
      break;
    case 8:
      digitalWrite (PIN_A,LOW);
      digitalWrite (PIN_B,LOW);
      digitalWrite (PIN_C,LOW);
      digitalWrite (PIN_D,HIGH);
      Serial.print ("8");
      break;
    case 9:
      digitalWrite (PIN_A,HIGH);
      digitalWrite (PIN_B,LOW);
      digitalWrite (PIN_C,LOW);
      digitalWrite (PIN_D,HIGH);
      Serial.print ("9");
      break;
  }
}
