#include <arduino.h>

#define SENSOR_PIN A3

void sensor_setup(void);
float muestra_corriente(void);
float get_corriente(int n_muestras);
