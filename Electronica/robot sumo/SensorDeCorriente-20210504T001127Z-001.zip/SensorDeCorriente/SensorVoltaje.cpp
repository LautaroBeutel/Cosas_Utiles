#include "SensorVoltaje.h"
#include "Digito.h"
float voltaje = 0;

float muestra_voltaje(void){
  float V = get_voltaje(2000); //Promedio de muestras
  //Serial.println(V);
  return V;
}
float get_voltaje(int n_muestras){
  for(int i = 0; i < n_muestras; i++){
    voltaje += analogRead(SENSOR_PIN)*(5.0/1023.0);
  }
  voltaje = voltaje/n_muestras;
  return (voltaje);
}
