#include <arduino.h>

#define PIN_A 3   //Pines de entrada
#define PIN_B 4
#define PIN_C 5
#define PIN_D 6
#define UNI_1 8   //Pines para activar cada digito por separado
#define UNI_2 9
#define UNI_3 10
#define UNI_4 11

void digito_setup();
float digito_activo(float valor);

void actualizar_numero();
